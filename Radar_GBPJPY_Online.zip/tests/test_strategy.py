import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from strategy import calculate_signals, last_closed_candles, rsi_wilder, PIP


def sample_data(length=1600):
    idx = pd.date_range('2026-09-01 00:00', periods=length, freq='15min', tz='UTC')
    t = np.arange(length)
    close = 200 + .015 * t + .32 * np.sin(t * .115)
    return pd.DataFrame({
        'open': close - .015,
        'high': close + .10,
        'low': close - .10,
        'close': close,
    }, index=idx)


def test_only_closed_bars():
    sample = sample_data(40)
    asof = sample.index[-1] + pd.Timedelta(minutes=10)
    result = last_closed_candles(sample, now=asof)
    assert result.index[-1] == sample.index[-2]


def test_indicators_and_prices():
    frame = calculate_signals(sample_data())
    assert len(frame) == 1600
    assert pd.notna(frame.ema20.iloc[-1])
    assert pd.notna(frame.h_ema200.iloc[-1])
    assert frame.trend.iloc[-1] in ('ALTA', 'BAIXA', 'NEUTRA')
    assert frame.stop_pips.dropna().min() >= 12
    assert PIP == .01
    alert = frame[frame.signal != 'AGUARDAR']
    if not alert.empty:
        for _, row in alert.iterrows():
            if row.signal == 'COMPRA':
                assert row.stop < row.entry < row.target1 < row.target2
            else:
                assert row.stop > row.entry > row.target1 > row.target2


def test_no_hourly_lookahead():
    d1 = sample_data()
    baseline = calculate_signals(d1)
    # Mexer violentamente apenas na ÚLTIMA hora não pode afetar sinais antigos.
    d2 = d1.copy()
    d2.loc[d2.index[-3:], 'close'] += 100
    modified = calculate_signals(d2)
    pd.testing.assert_series_equal(baseline.trend.iloc[:-4], modified.trend.iloc[:-4])
    pd.testing.assert_series_equal(baseline.signal.iloc[:-4], modified.signal.iloc[:-4])


def test_rsi_monotonic_up():
    close = pd.Series(np.linspace(100, 200, 100))
    assert rsi_wilder(close).iloc[-1] == 100
